/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBase {
public static Connection con(){
    
    try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:MYSQL://localhost:3306/jftech";
        String user = "root";
        String pass="";
        Connection con = DriverManager.getConnection(url, user, pass);
        return con;
    }catch (SQLException e){
    }
    catch (ClassNotFoundException e){
    }
    return null;
    }       
}
